---
layout: posts_by_category
categories: Pythonic
title: Pythonic
permalink: /category/Pythonic
---